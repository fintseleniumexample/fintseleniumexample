const { test, expect } = require('@playwright/test');

export async function assertIsTextEqualsPresent(text) {
  const page = process.playwrightPage;
  console.log(`assert text equals ${text}`)
  if (page.url().includes('/en')) {
    expect((await page.$$(`//*[text()='${text}']`)).length > 0, `Cannot find text [${text}]`).toBe(true);
  } else {
    console.log(`for non /en locales checking text is skipped`)
  }
}

export async function clickOnText(text) {
  const page = process.playwrightPage;
  console.log(`click on ${text}`);
  const locatorTextEquals = `//*[text()='${text}']`;
  const locatorTextContains = `//*[contains(text(),"${text}")]`;
  if ((await page.$$(locatorTextEquals)).length > 0) {
    await page.locator(locatorTextEquals).first().click();
  } else if ((await page.$$(locatorTextContains)).length > 0) {
    await page.locator(locatorTextContains).first().click();
  } else {
    expect(false, `Cannot find text [${text}]`).toBe(true);
  }
}

export async function waitForText(text, seconds) {
  const page = process.playwrightPage;
  if (page.url().includes('/en')) {
    console.log(`wait for text ${text} in EN only`)
    const ele = await page.getByText(`${text}`).first();
    await ele.waitFor({ state: "visible", timeout: seconds * 1000 })
  } else {
    await page.waitForTimeout(seconds * 1000);
  }
}

export async function waitForElement(locator, seconds) {
  const page = process.playwrightPage;
  const ele = await page.locator(locator).first();
  await ele.waitFor({ state: "visible", timeout: seconds * 1000 })
}

export async function isTextEqualsPresent(text) {
  const page = process.playwrightPage;
  return (await page.$$(`//*[text()="${text}"]`)).length > 0;
}

export async function isTextContainsVisible(text) {
  const page = process.playwrightPage;
  const locator = `//*[contains(text(),"${text}")]`;
  let visibility = false;
  if ((await page.$$(locator)).length > 0) {
    visibility = await (await page.$(locator)).isVisible();
  }
  return visibility;
}

export async function isElementDisplayed(locator) {
  const page = process.playwrightPage;
  let visibility = false;
  if ((await page.$$(locator)).length > 0) {
    visibility = await (await page.$(locator)).isVisible();
  }
  return visibility;
}

export async function assertTextEqualsIsVisible(text) {
  const page = process.playwrightPage;
  console.log(`assert text equals ${text} is visible`);
  const locator = `//*[normalize-space(text())='${text}']`;
  let visibility = false;
  if ((await page.$$(locator)).length > 0) {
    visibility = await (await page.$(locator)).isVisible();
  }
  expect(visibility, `Cannot find text [${text}]`).toBe(true);
}

export async function assertTextEqualsIsMissing(text) {
  const page = process.playwrightPage;
  console.log(`assert text equals ${text} is missing`);
  const locator = `//*[normalize-space(text())='${text}']`;
  let visibility = false;
  if ((await page.$$(locator)).length > 0) {
    visibility = await (await page.$(locator)).isVisible();
  }
  expect(visibility, `Text [${text}] should not be visible on the page`).toBe(false);
}

export async function assertTextContainsIsVisible(text) {
  console.log(`check text contains ${text} is visible`);
  const page = process.playwrightPage;

  // const locator = `//*[contains(text(),"${text}")]`;
  // let visibility = false;
  // if ((await page.$$(locator)).length > 0) {
  //   visibility = await (await page.$(locator)).isVisible();
  // }
  // expect(visibility, `Cannot find text [${text}]`).toBe(true);

  await expect(page.getByText(`${text}`).first()).toBeVisible();
}

export async function assertTextContainsIsMissing(text) {
  const page = process.playwrightPage;
  console.log(`check text contains ${text} is missing`);
  const locator = `//*[contains(text(),"${text}")]`;
  let visibility = false;
  if ((await page.$$(locator)).length > 0) {
    visibility = await (await page.$(locator)).isVisible();
  }
  expect(visibility, `Text [${text}] should not be visible on the page`).toBe(false);
}

export async function assertTextInElement(locator, expectedValue) {
  const page = process.playwrightPage;
  console.log(`check text ${expectedValue} in ${locator}`);
  const actualValue = await page.locator(locator).first().textContent();
  expect(actualValue.trim().replace(/\n/g, ' ')).toBe(expectedValue);
}

export async function getTextFromElement(locator) {
  const page = process.playwrightPage;
  console.log(`get text from locator [${locator}]`);
  const actualValue = await (await page.$(locator)).textContent();
  const result = actualValue.trim().replace(/\n/g, ' ');
  console.log();
  console.log(`text in locator [${locator}] = [${result}]`);
  console.log();
  return result;
}

export async function assertValueWithTextBefore(textBefore, expectedValue) {
  const page = process.playwrightPage;
  console.log(`assert value with text before [${textBefore}] = [${expectedValue}]`);
  await assertTextInElement(page, `//*[text()="${textBefore}"]/following::span[1]`, expectedValue);
}

export async function assertValueInInput(locator, expectedValue) {
  const page = process.playwrightPage;
  const actualValue = await (await page.$(locator)).getAttribute('value');
  expect(actualValue.trim()).toBe(expectedValue.toString());
}

export async function assertTextWithoutSpacesInElement(locator, expectedValue) {
  const page = process.playwrightPage;
  const actualValue = await (await page.$(locator)).textContent();
  expect(actualValue.trim().replace(/\s/g, '')).toBe(expectedValue);
}

export async function assertElementVisibility(locator, expectedVisibility) {
  const page = process.playwrightPage;
  console.log(`assert visibility for [${locator}] = [${expectedVisibility}]`);
  let visibility = false;
  if ((await page.$$(locator)).length > 0) {
    visibility = await (await page.$(locator)).isVisible();
  }
  expect(visibility, `unexpected visibility for element with locator ${locator}`).toBe(expectedVisibility);
}

export async function getAttributeFromElements(locator, attribute) {
  const page = process.playwrightPage;
  const elements = await page.$$(locator);
  const values = [];
  for (let el of elements) {
    values.push(await el.getAttribute(attribute));
  }
  return values;
}

export async function getTextFromElements(locator) {
  const page = process.playwrightPage;
  const elements = await page.$$(locator);
  const values = [];
  for (let el of elements) {
    values.push((await el.textContent()).trim());
  }
  return values;
}