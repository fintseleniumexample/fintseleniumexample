import path from 'path';
import XLSX from 'xlsx';
import { dataProvidersFolderWithExcelFiles } from '../config/new-cart.config';
import { doesFileExist } from './FileUtils';

export async function readExcelSheet(fileName, sheetName) {
  const workbook = XLSX.readFile(fileName);
  const xlData = XLSX.utils.sheet_to_json(workbook.Sheets[sheetName]);
  return xlData;
}

const excelFolderPath = dataProvidersFolderWithExcelFiles + path.sep;

export function readDataFromExcelFile(fileName) {
  const fullPath = excelFolderPath + fileName;
  console.log(`READING XLSX FILE ${fullPath}`)
  if (!doesFileExist(fullPath)) {
    throw new Error(`CANNOT FIND FILE ${fullPath}. PLEASE MAKE SURE IT EXISTS!`);
  }
  const workbook = XLSX.readFile(fullPath);
  const dataFromFirstSheet = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]]);
  return dataFromFirstSheet;
}