export function getDateAndTimeInString() {
  return (new Date()).toLocaleString().replace(/(:|\/)/g, '-').replace(/,/g, '').replace(/\s/g, '_');
}

export function getCurrentMonthAndYearForCard() {
  const date = new Date().toLocaleDateString(); // '8/6/2023'
  const dateArray = date.split('/');
  const month = dateArray[0].length === 1 ? '0' + dateArray[0] : dateArray[0];
  const year = dateArray[2].slice(-2);
  return month + year;
}

export function generateRandomString(length) {
  let result = '';
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
  const charactersLength = characters.length;
  let counter = 0;
  while (counter < length) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
    counter += 1;
  }
  return result;
}

export function generateRandomStringFromNumbers(length) {
  let result = '';
  const characters = '123456789';
  const charactersLength = characters.length;
  let counter = 0;
  while (counter < length) {
    result += characters.charAt(Math.floor(Math.random() * charactersLength));
    counter += 1;
  }
  return result;
}

export function generateRandomNumber() {
  return Math.floor(Math.random() * 1000);
}

export function multiplyPrice(price, quantity) { // '$48.00',2
  let a = price;
  let b = a.substring(1);
  let c = b * Number(quantity); // 96
  let d = '$' + parseFloat(c).toFixed(2);
  return d;
}

export function calculateTotal(priceStringsArray) {
  let total = 0.00;
  for (let i = 0; i < priceStringsArray.length; i++) {
    total += parseFloat(priceStringsArray[i].replace('$', ''))
  }
  return '$' + parseFloat(total).toFixed(2);;
}