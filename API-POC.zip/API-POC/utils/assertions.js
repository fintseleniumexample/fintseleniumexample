const { expect } = require('@playwright/test');
import { ProductListComponent } from '../pages/pageComponents/ProductListComponent';

export async function assertTextEqualsIsVisible(page, text) {
  console.log(`check text equals [${text}] is visible`);
  const locator = `//*[normalize-space(text())='${text}']`;
  let visibility = false;
  if ((await page.$$(locator)).length > 0) {
    visibility = await (await page.$(locator)).isVisible();
  }
  expect(visibility, `Cannot find text [${text}]`).toBe(true);
}

export async function assertTextContainsIsVisible(page, text) {
  console.log(`check text contains [${text}] is visible`);
  const locator = `//*[contains(text(),"${text}")]`;
  let visibility = false;
  if ((await page.$$(locator)).length > 0) {
    visibility = await (await page.$(locator)).isVisible();
  }
  expect(visibility, `Cannot find text [${text}]`).toBe(true);
}

export async function assertTextContainsPresent(page, text) {
  console.log(`check text contains [${text}] present`);
  const locator = `//*[contains(text(),"${text}")]`;
  let visibility = false;
  if ((await page.$$(locator)).length > 0) {
    visibility = true;
  }
  expect(visibility, `Cannot find text [${text}]`).toBe(true);
}

export async function assertNumberOfResultsInTheCounterOnTheTop(page, min, max) {
  console.log(`assert number of results >= ${min} and <= ${max}`);
  const productListComponent = new ProductListComponent(page);
  const resultsFound = await productListComponent.getNumberOfResultsInTheCounterOnTheTop();
  expect(resultsFound).toBeGreaterThanOrEqual(min);
  expect(resultsFound).toBeLessThanOrEqual(max);
}

export async function assertTextInElement(page, locator, expectedValue) {
  console.log(`check text ${expectedValue} in ${locator}`);
  const actualValue = await page.locator(locator).first().textContent();
  expect(actualValue.trim().replace(/\n/g, ' ')).toBe(expectedValue);
}

export async function assertValueInInput(page, locator, expectedValue) {
  const actualValue = await (await page.$(locator)).getAttribute('value');
  expect(actualValue.trim()).toBe(expectedValue);
}

export async function assertIsTextEqualsPresent(page, text) {
  console.log(`assert text equals ${text}`)
  if (page.url().includes('/en')) {
    expect((await page.$$(`//*[text()='${text}']`)).length > 0, `Cannot find text [${text}]`).toBe(true);
  } else {
    console.log(`for non /en locales checking text is skipped`)
  }
}

export async function assertElementVisibility(page, locator, expectedVisibility) {
  console.log(`assert visibility for [${locator}] = [${expectedVisibility}]`);
  let visibility = false;
  if ((await page.$$(locator)).length > 0) {
    visibility = await (await page.$(locator)).isVisible();
  }
  expect(visibility, `unexpected visibility for element with locator ${locator}`).toBe(expectedVisibility);
}