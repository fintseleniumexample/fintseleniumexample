export const dataProvidersFolderWithExcelFiles = 'tests-data';


export const env = '';

